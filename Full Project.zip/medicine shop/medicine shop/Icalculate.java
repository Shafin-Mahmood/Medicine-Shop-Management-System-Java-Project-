



public interface Icalculate {
    public void getSum();
    public void getBill();
    
}
